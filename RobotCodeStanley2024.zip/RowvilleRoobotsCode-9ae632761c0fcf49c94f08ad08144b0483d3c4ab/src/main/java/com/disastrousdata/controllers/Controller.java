/*
Controller.java
Written by CoPokBl

This is implemented by all controller mappings.
DO NOT CHANGE THIS.
*/

package com.disastrousdata.controllers;

public interface Controller {
    int getButtonId();
}
